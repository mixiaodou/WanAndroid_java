package com.brucej.wanandroid_java.ui;


import com.example.lib_comon.base.BaseModel;

public class MainModel extends BaseModel {
}
