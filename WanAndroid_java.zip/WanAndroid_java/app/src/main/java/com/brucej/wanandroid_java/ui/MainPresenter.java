package com.brucej.wanandroid_java.ui;
import com.example.lib_comon.base.BasePresenter;

public class MainPresenter extends BasePresenter<MainIView, MainModel> {

}
