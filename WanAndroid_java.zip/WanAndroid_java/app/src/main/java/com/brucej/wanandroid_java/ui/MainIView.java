package com.brucej.wanandroid_java.ui;


import com.example.lib_comon.base.BaseIView;

public interface MainIView extends BaseIView {
    void switchTittle(String tittle);
}
