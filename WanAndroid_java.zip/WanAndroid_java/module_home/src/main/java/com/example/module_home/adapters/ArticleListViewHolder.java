package com.example.module_home.adapters;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.brucej.wanandroid_java.R;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ArticleListViewHolder extends BaseViewHolder {

    @BindView(R.id.item_article_list_authorImg)
    public ImageView authorImg;
    @BindView(R.id.item_article_list_authornameTv)
    public TextView authorTv;
    @BindView(R.id.item_article_list_typeTv)
    public TextView typeTv;
    @BindView(R.id.item_article_list_contentTv)
    public TextView contentTv;
    @BindView(R.id.item_article_list_timeTv)
    public TextView timeTv;
    @BindView(R.id.item_article_list_newtagTv)
    public TextView newtagTv;
    @BindView(R.id.item_article_list_projecttagTv)
    public TextView projecttagTv;


    public ArticleListViewHolder(View view) {
        super(view);
        ButterKnife.bind(this, view);
    }
}
