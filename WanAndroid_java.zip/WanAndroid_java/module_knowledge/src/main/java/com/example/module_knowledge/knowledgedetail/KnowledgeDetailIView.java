package com.example.module_knowledge.knowledgedetail;


import com.example.lib_comon.base.BaseIView;

public interface KnowledgeDetailIView extends BaseIView {
}
