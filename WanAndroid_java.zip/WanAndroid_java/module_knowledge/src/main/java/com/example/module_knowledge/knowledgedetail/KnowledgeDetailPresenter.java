package com.example.module_knowledge.knowledgedetail;


import com.example.lib_comon.base.BasePresenter;

public class KnowledgeDetailPresenter extends BasePresenter<KnowledgeDetailIView, KnowledgeDetailModel> {
}
