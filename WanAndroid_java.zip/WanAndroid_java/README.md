# WanAndroid_java
借用玩Android接口 玩一玩
## 这个样子-
![](https://github.com/mixiaodou/WanAndroid_java/blob/master/sample/demo1.png)
![](https://github.com/mixiaodou/WanAndroid_java/blob/master/sample/demo2.png)
![](https://github.com/mixiaodou/WanAndroid_java/blob/master/sample/demo3.png)
