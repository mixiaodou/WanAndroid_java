package debug;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.module_h5.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
