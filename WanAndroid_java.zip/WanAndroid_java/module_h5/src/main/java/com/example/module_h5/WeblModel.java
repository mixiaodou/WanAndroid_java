package com.example.module_h5;


import com.example.lib_comon.base.BaseModel;

public class WeblModel extends BaseModel {
}
