package com.example.module_h5;


import com.example.lib_comon.base.BaseIView;

public interface WebIView extends BaseIView {

    void setTittle(String tittle);
}
