package com.example.lib_comon.app;

//定义常量
public interface Constants {
}
