package com.example.lib_comon.base;

public interface BaseIView {

    void useNightMode(boolean isNightMode);

    void showToast(String msg);

    void showSnackBar(String msg);

}

