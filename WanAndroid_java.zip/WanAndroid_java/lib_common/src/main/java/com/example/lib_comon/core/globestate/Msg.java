package com.example.lib_comon.core.globestate;

public abstract class Msg {
}
